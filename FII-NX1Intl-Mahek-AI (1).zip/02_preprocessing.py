"""
Step 2: Preprocessing
Clean and tokenize the data.
"""
import pandas as pd
import re

def clean_text(text):
    text = text.lower()
    text = re.sub(r"[^a-zA-Z0-9\s]", "", text)
    return text

df = pd.read_csv("harassment_dataset.csv")
df["clean_text"] = df["text"].apply(clean_text)
df.to_csv("cleaned_dataset.csv", index=False)
print("Cleaned dataset saved as cleaned_dataset.csv")
