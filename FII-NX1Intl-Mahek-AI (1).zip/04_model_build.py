"""
Step 4: Model Architecture (using Keras Sequential API)
"""
from keras.models import Sequential
from keras.layers import Embedding, GlobalAveragePooling1D, Dense

def build_model(vocab_size):
    model = Sequential([
        Embedding(input_dim=vocab_size, output_dim=16, input_length=20),
        GlobalAveragePooling1D(),
        Dense(16, activation='relu'),
        Dense(1, activation='sigmoid')
    ])
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model
