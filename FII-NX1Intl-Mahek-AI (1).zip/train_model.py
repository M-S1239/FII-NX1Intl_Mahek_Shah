"""
Final Combined Script: Train & Predict HarassNet
"""
import pandas as pd
from keras.models import Sequential
from keras.layers import Embedding, GlobalAveragePooling1D, Dense
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences

data = {
    "text": [
        "You are worthless here.",
        "Let's work on this project together.",
        "You're just a pretty face.",
        "Great job on the presentation!",
        "You should smile more."
    ],
    "label": [1, 0, 1, 0, 1]
}
df = pd.DataFrame(data)
df["text"] = df["text"].str.lower().str.replace(r"[^a-zA-Z0-9\s]", "", regex=True)

tokenizer = Tokenizer(num_words=1000, oov_token="<OOV>")
tokenizer.fit_on_texts(df["text"])
sequences = tokenizer.texts_to_sequences(df["text"])
padded = pad_sequences(sequences, maxlen=20)

X = padded
y = df["label"]

model = Sequential([
    Embedding(input_dim=1000, output_dim=16, input_length=20),
    GlobalAveragePooling1D(),
    Dense(16, activation='relu'),
    Dense(1, activation='sigmoid')
])

model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
model.fit(X, y, epochs=10, verbose=1)
model.save("harassnet_model.h5")
