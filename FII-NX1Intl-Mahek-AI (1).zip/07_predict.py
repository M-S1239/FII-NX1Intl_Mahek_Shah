"""
Step 7: Predict New Text
"""
from keras.models import load_model
from keras.preprocessing.sequence import pad_sequences
from sklearn.feature_extraction.text import Tokenizer

model = load_model("harassnet_model.h5")

texts = ["You should smile more."]

tokenizer = Tokenizer(num_words=1000, oov_token="<OOV>")
tokenizer.fit_on_texts(texts)
sequences = tokenizer.texts_to_sequences(texts)
padded = pad_sequences(sequences, maxlen=20)
predictions = model.predict(padded)
print("Prediction:", "Harassment" if predictions[0][0] > 0.5 else "Not Harassment")
