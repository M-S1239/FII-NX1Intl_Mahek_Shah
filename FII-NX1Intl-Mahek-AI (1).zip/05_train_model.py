"""
Step 5: Train Model
"""
import pandas as pd
from sklearn.feature_extraction.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from 04_model_build import build_model

X_train = pd.read_csv("X_train.csv").squeeze()
y_train = pd.read_csv("y_train.csv").squeeze()

tokenizer = Tokenizer(num_words=1000, oov_token="<OOV>")
tokenizer.fit_on_texts(X_train)
X_train_seq = tokenizer.texts_to_sequences(X_train)
X_train_pad = pad_sequences(X_train_seq, maxlen=20)

model = build_model(vocab_size=1000)
model.fit(X_train_pad, y_train, epochs=10, verbose=1)
model.save("harassnet_model.h5")
print("Model trained and saved as harassnet_model.h5")
