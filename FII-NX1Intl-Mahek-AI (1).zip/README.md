# HarassNet AI Tool

**SDG Focus:** Gender Equality (SDG 5) – specifically Target 5.1: "End all forms of discrimination against all women and girls everywhere."

**Tool Summary:** HarassNet is a text classification model trained to detect gender-based microaggressions or workplace harassment. It uses deep learning (Keras Sequential model with embedding + dense layers) on text samples. The model achieves over 90% training accuracy on simulated data and includes preprocessing and prediction modules for new user input.

To run the model:
```bash
python train_model.py
python 07_predict.py
```

All training and preprocessing code is included.
