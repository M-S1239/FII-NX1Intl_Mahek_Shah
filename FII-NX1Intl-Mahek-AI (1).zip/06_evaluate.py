"""
Step 6: Evaluate Model
"""
import pandas as pd
from sklearn.metrics import classification_report
from keras.models import load_model
from keras.preprocessing.sequence import pad_sequences
from sklearn.feature_extraction.text import Tokenizer

X_test = pd.read_csv("X_test.csv").squeeze()
y_test = pd.read_csv("y_test.csv").squeeze()

tokenizer = Tokenizer(num_words=1000, oov_token="<OOV>")
tokenizer.fit_on_texts(X_test)
X_test_seq = tokenizer.texts_to_sequences(X_test)
X_test_pad = pad_sequences(X_test_seq, maxlen=20)

model = load_model("harassnet_model.h5")
y_pred = (model.predict(X_test_pad) > 0.5).astype("int32")

print(classification_report(y_test, y_pred))
