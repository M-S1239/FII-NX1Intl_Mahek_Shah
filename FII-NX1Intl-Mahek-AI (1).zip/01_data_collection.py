"""
Step 1: Data Collection
Collect and simulate workplace harassment-related messages.
"""
import pandas as pd

# Simulated dataset
data = {
    "text": [
        "You are worthless here.",
        "Let's work on this project together.",
        "You're just a pretty face.",
        "Great job on the presentation!",
        "You should smile more."
    ],
    "label": [1, 0, 1, 0, 1]  # 1 = Harassment, 0 = Non-harassment
}

df = pd.DataFrame(data)
df.to_csv("harassment_dataset.csv", index=False)
print("Dataset saved as harassment_dataset.csv")
